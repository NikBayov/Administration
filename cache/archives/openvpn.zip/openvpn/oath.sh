#!/bin/bash

# Скрипт для проверки MFA с использованием oathtool

passfile=$1

# Проверка, что файл с паролем передан и существует
if [ -z "$passfile" ] || [ ! -f "$passfile" ]; then
    echo "Passfile not provided or does not exist"
    exit 1
fi

# Получение имени пользователя и пароля из временного файла
user=$(head -1 "$passfile")
pass=$(tail -1 "$passfile")

# Проверка, что имя пользователя и пароль получены
if [ -z "$user" ] || [ -z "$pass" ]; then
    echo "USER_OR_PASS_NOT_FOUND"
    exit 1
fi

# Поиск записи в файле oath.secrets, игнорируя регистр
secret=$(grep -i -m 1 "^${user}:" /etc/openvpn/oath.secrets | cut -d: -f2)

# Проверка, что секрет найден
if [ -z "$secret" ]; then
    echo "USER_NOT_FOUND"
    exit 1
fi

# Вычисление ожидаемого кода
code=$(oathtool --totp "$secret")

# Проверка, содержит ли пароль разделитель для пароля и MFA
if echo "$pass" | grep -q ":"; then
    realpass=$(echo "$pass" | cut -d: -f1)
    mfatoken=$(echo "$pass" | cut -d: -f2)

    # Проверка пароля пользователя из файла user_credentials.txt
    stored_pass=$(grep -i -m 1 "^${user}:" /etc/openvpn/user_credentials.txt | cut -d: -f2)

    if [ "$realpass" = "$stored_pass" ] && [ "$mfatoken" = "$code" ]; then
        echo "Authentication successful"
        exit 0
    fi
else
    # Если пароль не содержит разделителя, проверяем только MFA токен
    if [ "$pass" = "$code" ]; then
        echo "Authentication successful"
        exit 0
    fi
fi

# Если мы дошли до этого места, аутентификация не удалась
echo "User: $user"
echo "Pass: $pass"
echo "Secret: $secret"
echo "Generated TOTP Code: $code"
echo "Authentication failed"
exit 1
