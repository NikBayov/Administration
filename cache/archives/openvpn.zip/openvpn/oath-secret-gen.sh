#!/bin/bash

# Установите строку издателя здесь. Убедитесь, что она URL-кодирована.
issuer='MFA%20Sample'

# Генерация случайного хэша пользователя
userhash=$(head -c 30 /dev/urandom | sha256sum | cut -b 1-30)

# Генерация Base32 секрета с использованием oathtool
base32=$(oathtool --totp -v "$userhash" | grep 'Base32 secret' | awk '{print $3}')

# Вывод строки для пользователя
echo "User String:"
echo "otpauth://totp/$issuer:$1?secret=$base32"

# Вывод записи для файла oath.secrets
echo "oath.secrets entry:"
echo "$1:$userhash"