from flask import Flask, request, render_template, redirect, url_for, session
import subprocess
import logging

app = Flask(__name__)

# Установите секретный ключ для сессий
app.secret_key = 'your_secret_key_here'

LDAP_SERVER = "ldap://<your-domain>:3268"
QR_CODE_PATH = "/var/www/ovpn/static/qr-klients"

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

# Создаем обработчик для записи логов в файл
file_handler = logging.FileHandler('app.log')
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

# Добавляем обработчик к логгеру
logger = logging.getLogger()
logger.addHandler(file_handler)

def authenticate(username, password):
    try:
        user_with_domain = f"{username}@nextcontact.ru"
        logging.debug(f"Authenticating user: {user_with_domain}")
        
        command = [
            "ldapsearch", "-x", "-H", LDAP_SERVER,
            "-D", user_with_domain,
            "-w", password,
            f"(givenName={username})"
        ]
        
        result = subprocess.run(command, capture_output=True, text=True)
        logging.debug(f"LDAP search command output: {result.stdout}")
        
        if result.returncode == 0 and "givenName" in result.stdout:
            logging.info("Authentication successful")
            return True
        else:
            logging.warning("Authentication failed")
            return False
    except Exception as e:
        logging.error(f"Error during LDAP authentication: {e}")
        return False

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        logging.debug(f"Form Data: {request.form}")
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            logging.warning("Username or password is missing in request")
            return "Missing username or password", 400

        logging.debug(f"Received login attempt for user: {username}")
        if authenticate(username, password):
            session['username'] = username # Сохраняем имя пользователя в сессии
            return redirect(url_for('show_qr', username=username))
        else:
            return "Invalid credentials", 401
    return render_template('login.html')

@app.route('/qr/<username>')
def show_qr(username):
    if 'username' not in session or session['username'] != username:
        return "Unauthorized access", 403 # Проверяем, что пользователь авторизован и имеет доступ

    qr_code_file = f"qr-klients/{username}.png"
    return render_template('qr.html', qr_code_file=qr_code_file)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)